<script
  src="https://kit.fontawesome.com/1b1227959d.js"
  crossorigin="anonymous"
></script>;
